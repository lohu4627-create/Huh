# RadiaNano Android app

Android USB-serial monitor for an Arduino-based radiation-sensor prototype.

## Build without Android Studio

The repository includes `.github/workflows/build-apk.yml`.

1. Upload the **contents** of this project to the root of a GitHub repository (do not upload this ZIP as one file).
2. Open **Actions** → **Build RadiaNano APK** → **Run workflow**.
3. When the run succeeds, open it and download the `RadiaNano-APK` artifact.
4. Extract the artifact ZIP and install `app-debug.apk` on Android.

## Arduino serial protocol

Set the Arduino serial port to **9600 baud**. Send newline-terminated lines such as:

```text
CPM:12
PULSE:345
```

The app displays these values; it does not calculate dose rate or calibrate the sensor.

## Hardware notes

Connect the Arduino through a USB-OTG adapter and a **data-capable** USB cable. Grant the Android USB permission prompt. This app reads serial data; the Arduino firmware and analog front-end for a photodiode/scintillator detector must be developed and calibrated separately.

## Requirements

- Android 6.0 or newer
- USB host/OTG support for wired serial connection
- USB serial adapter/chip supported by `usb-serial-for-android`
