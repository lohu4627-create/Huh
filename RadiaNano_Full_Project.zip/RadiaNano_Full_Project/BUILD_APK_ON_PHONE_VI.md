# Hướng dẫn tạo APK bằng điện thoại

1. Giải nén `RadiaNano_Full_Project.zip` trên điện thoại.
2. Mở repository GitHub → **Add file** → **Upload files**.
3. Chọn và tải lên TOÀN BỘ NỘI DUNG đã giải nén, không tải ZIP nguyên khối. Giữ nguyên thư mục `app` và `.github/workflows`.
4. Kiểm tra ở thư mục gốc repository phải thấy `app`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`.
5. Mở **Actions** → **Build RadiaNano APK** → **Run workflow**.
6. Khi có dấu tick xanh, mở lần chạy → tải artifact `RadiaNano-APK`.
7. Giải nén artifact và cài `app-debug.apk`.

Nếu GitHub trên điện thoại không cho tải lên nhiều tệp/thư mục cùng lúc, cần dùng một ứng dụng Git hỗ trợ commit/push thư mục dự án hoặc máy tính. Đừng tải ZIP như một tệp đơn vào repository.
