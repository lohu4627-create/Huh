package com.radianano.app

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var status: TextView
    private lateinit var cpmView: TextView
    private lateinit var pulseView: TextView
    private lateinit var logView: TextView
    private var port: UsbSerialPort? = null
    private var connected = false
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val actionUsbPermission = "com.radianano.app.USB_PERMISSION"
    private val buffer = StringBuilder()

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == actionUsbPermission) {
                val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && device != null) {
                    openDevice(device)
                } else {
                    setStatus("Chưa được cấp quyền USB")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        registerReceiver(permissionReceiver, IntentFilter(actionUsbPermission))
        buildScreen()
        setStatus("Chưa kết nối · Cắm Arduino qua USB OTG")
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        val title = TextView(this).apply {
            text = "☢  RadiaNano"
            textSize = 28f
            setTextColor(0xFF172033.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 18)
            setTextColor(0xFF526176.toInt())
        }
        cpmView = metric("CPM", "—")
        pulseView = metric("Tổng xung", "—")
        val connect = Button(this).apply {
            text = "KẾT NỐI USB"
            setOnClickListener { findAndConnect() }
        }
        val disconnect = Button(this).apply {
            text = "NGẮT KẾT NỐI"
            setOnClickListener { closePort(); setStatus("Đã ngắt kết nối") }
        }
        val note = TextView(this).apply {
            text = "Giao tiếp USB Serial · 9600 baud\nArduino gửi từng dòng: CPM:12 hoặc PULSE:345"
            textSize = 13f
            setTextColor(0xFF526176.toInt())
            setPadding(4, 18, 4, 12)
        }
        val logTitle = TextView(this).apply {
            text = "Nhật ký dữ liệu"
            textSize = 18f
            setTextColor(0xFF172033.toInt())
            setPadding(0, 12, 0, 8)
        }
        logView = TextView(this).apply {
            text = "Chưa có dữ liệu."
            textSize = 13f
            setTextColor(0xFF526176.toInt())
            setPadding(12, 12, 12, 12)
        }
        val scroll = ScrollView(this).apply { addView(logView) }
        root.addView(title, matchWrap())
        root.addView(status, matchWrap())
        root.addView(cpmView, matchWrap())
        root.addView(pulseView, matchWrap())
        root.addView(connect, matchWrap())
        root.addView(disconnect, matchWrap())
        root.addView(note, matchWrap())
        root.addView(logTitle, matchWrap())
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun metric(label: String, value: String): TextView = TextView(this).apply {
        text = "$label\n$value"
        textSize = 23f
        setTextColor(0xFF102A43.toInt())
        setBackgroundColor(0xFFFFFFFF.toInt())
        setPadding(20, 22, 20, 22)
        val p = LinearLayout.LayoutParams(-1, -2)
        p.setMargins(0, 8, 0, 8)
        layoutParams = p
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun findAndConnect() {
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (drivers.isEmpty()) {
            setStatus("Không tìm thấy USB Serial. Kiểm tra OTG, cáp dữ liệu và Arduino.")
            return
        }
        val driver = drivers[0]
        val device = driver.device
        if (!usbManager.hasPermission(device)) {
            val intent = PendingIntent.getBroadcast(this, 0, Intent(actionUsbPermission), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
            usbManager.requestPermission(device, intent)
        } else openDevice(device)
    }

    private fun openDevice(device: UsbDevice) {
        try {
            val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
                ?: throw IOException("Thiết bị không có driver serial phù hợp")
            val connection = usbManager.openDevice(device) ?: throw IOException("Không mở được USB device")
            val serialPort = driver.ports.firstOrNull() ?: throw IOException("Không tìm thấy cổng serial")
            serialPort.open(connection)
            serialPort.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            port = serialPort
            connected = true
            setStatus("Đã kết nối USB · 9600 baud")
            worker.execute { readLoop(serialPort) }
        } catch (e: Exception) {
            setStatus("Lỗi kết nối: ${e.message}")
        }
    }

    private fun readLoop(serialPort: UsbSerialPort) {
        val bytes = ByteArray(256)
        while (connected && port === serialPort) {
            try {
                val count = serialPort.read(bytes, 1000)
                if (count > 0) {
                    val chunk = String(bytes, 0, count, Charsets.UTF_8)
                    main.post { consume(chunk) }
                }
            } catch (e: Exception) {
                main.post { setStatus("Mất kết nối: ${e.message}"); closePort() }
                break
            }
        }
    }

    private fun consume(chunk: String) {
        for (ch in chunk) {
            if (ch == '\n' || ch == '\r') {
                val line = buffer.toString().trim()
                buffer.clear()
                if (line.isNotEmpty()) parseLine(line)
            } else if (buffer.length < 200) buffer.append(ch)
        }
    }

    private fun parseLine(line: String) {
        when {
            line.startsWith("CPM:", true) -> cpmView.text = "CPM\n${line.substringAfter(':').trim()}"
            line.startsWith("PULSE:", true) -> pulseView.text = "Tổng xung\n${line.substringAfter(':').trim()}"
        }
        logView.text = ("$line\n" + logView.text).take(4000)
    }

    private fun setStatus(message: String) {
        if (::status.isInitialized) status.text = message
    }

    private fun closePort() {
        connected = false
        try { port?.close() } catch (_: Exception) { }
        port = null
    }

    override fun onDestroy() {
        closePort()
        try { unregisterReceiver(permissionReceiver) } catch (_: Exception) { }
        worker.shutdownNow()
        super.onDestroy()
    }
}
